@echo off
rem Runs gco-install.exe from this folder; extra arguments are passed through.
"%~dp0gco-install.exe" install %*
pause
