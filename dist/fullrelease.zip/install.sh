#!/bin/sh
# Runs gco-install from this folder. If needed first: chmod +x install.sh gco-install
cd "$(dirname "$0")" || exit 1
exec ./gco-install install "$@"
